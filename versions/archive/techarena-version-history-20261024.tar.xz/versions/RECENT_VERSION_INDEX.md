# Career Simulation: preserved strategy candidates

Versioned snapshots beginning after the repository's previously archived v0.5.1 files.
The repository's root `solution/` remains unchanged; these folders preserve historical implementations.

| Version | Status |
|---|---|
| `v0.3.11` | Historical candidate; kept for comparison, not a current submission. |
| `v0.6` | Historical run: A 73.50, L5 (earlier local environment). |
| `v0.7` | Validated historical baseline: A 72.96, L6, completed 48 months (earlier local environment). |
| `v0.8` | Failed historical run: ended M11, 14.25. |
| `v0.8.1` | Failed historical run: ended M44, D 46.18, L4. |
| `v0.8.2` | Failed dev run (engine 1.0.6 / dev data 1.0.7): ended M24, L1, 20.61. |
| `v0.9` | Completed dev run (engine 1.0.6 / dev data 1.0.7): 48 months, L5, 68.14. |
| `v0.9-action-gate-candidate` | UNTESTED action-gate candidate, distinct from the v0.9 run above. |

V0.9-action-gate-candidate was not used in the reported V0.9 68.14 run.
Historical scores are from local development emulator runs, not official competition results.
Avoid uploading secrets, raw runtime databases, and unredacted personal logs to this public repository.
